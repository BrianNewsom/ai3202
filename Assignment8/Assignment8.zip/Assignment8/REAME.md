# Assignment 8

This assignment builds the probabilities for a hidden markov model.


## Run
```
	python main.py
```

OR

```
	./gen_output.sh
```

The output will be found in output.txt, containing all types of probabilities.  This is a pretty large file!