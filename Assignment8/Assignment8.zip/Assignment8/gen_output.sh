#!/bin/bash

python main.py | cat >> output.txt